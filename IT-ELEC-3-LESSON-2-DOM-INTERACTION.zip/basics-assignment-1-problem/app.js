const app = Vue.createApp({
    data:function(){
        return{
            name:'     JOHN MAR',
            age:' 21',
            years:' 26',
            imgSrc:'https://assets.nintendo.com/image/upload/c_pad,f_auto,h_613,q_auto,w_1089/ncom/en_US/games/switch/i/i-am-dead-switch/hero?v=2021091520',
            favNum:'0.15432',
        };
    },
});

app.mount('#assignment')

console.log