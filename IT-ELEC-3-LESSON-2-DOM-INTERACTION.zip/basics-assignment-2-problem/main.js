new Vue({
    el: '.event',
    data: {
        output1:'',
        output2:''
        },
    
    methods:{
    ShowAlert()
    {
        alert('Alert!');
    },
    setoutput1(event){
        this.output1=event.target.value;
    },
    setoutput2(event){
        this.output2=event.target.value;
    },
    },
    
    })

